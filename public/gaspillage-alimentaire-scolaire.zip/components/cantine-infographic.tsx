import Image from "next/image"

export function CantineInfographic() {
  return (
    <div className="w-full max-w-5xl overflow-hidden rounded-2xl bg-cantine text-cantine-ink shadow-2xl">
      <div className="px-6 py-10 sm:px-12 sm:py-14">
        {/* Title */}
        <h1 className="text-balance text-center text-4xl font-extrabold leading-tight text-white sm:text-6xl">
          Le gaspillage à la cantine
        </h1>

        {/* Intro */}
        <p className="mx-auto mt-6 max-w-3xl text-pretty text-center text-base font-medium leading-relaxed text-cantine-ink sm:mt-8 sm:text-xl">
          Chaque jour, la restauration scolaire sert des millions de repas. Mais une part
          importante finit à la poubelle :{" "}
          <span className="font-extrabold text-white">
            près de 120 g de nourriture gaspillés par élève et par repas
          </span>{" "}
          — entrées à peine touchées, pain, restes de plat.
        </p>

        {/* Divider */}
        <div className="my-10 h-px w-full bg-cantine-ink/70" />

        {/* Stats grid */}
        <div className="grid grid-cols-1 gap-y-14 md:grid-cols-2 md:gap-x-8">
          {/* Left block */}
          <div className="flex flex-col items-center">
            <div className="flex w-full items-center justify-center gap-4">
              <div className="text-right">
                <p className="text-2xl font-extrabold leading-tight text-white sm:text-3xl">
                  Un élève jette
                </p>
              </div>
            </div>

            <div className="mt-4 flex w-full items-center justify-center gap-4 sm:gap-8">
              <div className="flex flex-col items-center">
                <span className="text-6xl font-black leading-none text-cantine-ink sm:text-8xl">
                  30
                  <span className="text-4xl sm:text-6xl">kg</span>
                </span>
                <span className="mt-2 max-w-[10rem] text-center text-lg font-bold leading-tight text-white sm:text-xl">
                  de nourriture par an
                </span>
              </div>

              <div className="relative flex flex-col items-center">
                <span className="mb-1 text-lg font-bold italic text-cantine-ink">dont</span>
                <Image
                  src="/images/poubelle-ouverte.png"
                  alt="Illustration d'une poubelle ouverte"
                  width={180}
                  height={200}
                  className="h-36 w-auto sm:h-44"
                />
                <div className="pointer-events-none absolute inset-x-0 top-1/2 flex -translate-y-1/2 flex-col items-center">
                  <span className="text-4xl font-black leading-none text-white sm:text-5xl">
                    120
                    <span className="text-2xl sm:text-3xl">g</span>
                  </span>
                  <span className="text-center text-sm font-bold leading-tight text-white sm:text-base">
                    jetés à
                    <br />
                    chaque repas
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-8 h-px w-4/5 bg-cantine-ink/70 md:hidden" />
          </div>

          {/* Right block */}
          <div className="flex flex-col items-center">
            <p className="text-center text-2xl font-extrabold leading-tight text-white sm:text-3xl">
              Le coût de ce gaspillage
              <br />
              atteint
            </p>

            <div className="relative mt-4 flex items-center justify-center">
              <Image
                src="/images/benne-noire.png"
                alt="Illustration d'une benne à ordures noire"
                width={360}
                height={320}
                className="h-56 w-auto sm:h-64"
              />
              <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center pt-6">
                <span className="text-5xl font-black leading-none text-cantine sm:text-6xl">
                  200€
                </span>
                <span className="mt-1 text-center text-lg font-extrabold leading-tight text-cantine sm:text-xl">
                  par élève
                  <br />
                  par an
                </span>
              </div>
            </div>

            <p className="mt-4 max-w-sm text-pretty text-center text-sm font-bold leading-snug text-cantine-ink">
              Soit des millions d&apos;euros de repas jetés chaque année en France,
              alors que ces aliments étaient parfaitement consommables.
            </p>
          </div>
        </div>

        {/* Footer solutions */}
        <div className="mt-12 border-t border-cantine-ink/70 pt-8">
          <p className="text-center text-lg font-extrabold text-white sm:text-2xl">
            Comment agir à la cantine ?
          </p>
          <div className="mx-auto mt-6 grid max-w-3xl grid-cols-1 gap-4 sm:grid-cols-3">
            {[
              "Se servir de plus petites portions et se resservir si besoin",
              "Peser les déchets pour sensibiliser toute l'école",
              "Donner les invendus à des associations ou au compost",
            ].map((tip, i) => (
              <div
                key={i}
                className="rounded-xl bg-cantine-ink/15 p-4 text-center text-sm font-semibold leading-snug text-cantine-ink"
              >
                {tip}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
