import { CantineInfographic } from "@/components/cantine-infographic"

export default function Page() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-muted p-4 sm:p-8">
      <CantineInfographic />
    </main>
  )
}
